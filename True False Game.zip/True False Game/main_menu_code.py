from question_model import Question
from data import question_data
from quiz_brain import QuizBrain

question_bank = []


for question in question_data:
        question_text = question["text"] #change this if you get a new data set
        question_answer = question["answer"] #also change this if new data has different keys
        new_question = Question(question_text,question_answer)
        question_bank.append(new_question)
        
            
quiz = QuizBrain(question_bank)

quiz.next_question() # this line isn't essential

while quiz.still_has_questions():
    quiz.check_answer
    quiz.next_question()

#attibutes in this project = question_number = 0, questions_list = [] , score = 0
#methods in this project = next_question(), still_has_questions(), check_answer()


    


